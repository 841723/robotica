Github containing the code for the Robotics subject in the Computer Engineering Degree of Universidad de Zaragoza.

Autores: 839385 Miguel Arasanz, 844417 Andrei Dumbrava, 841723 Diego Roldán.

**Uso:**

Genera las claves ssh ejecutando key-gen.sh

Para ejecutar el fichero Python en cuestión, configurar en exec.sh y ejecutarlo.

**Cambios realizados sobre el formato original:**

Ninguno